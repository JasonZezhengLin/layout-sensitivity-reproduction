from pathlib import Path
import ast, hashlib, json, time
SEED="TD7_LAYOUT_SEMANTIC50_V1"
LAYOUTS=("layout-0","layout-1","layout-2","layout-3")

def sha(s):return hashlib.sha256(s.encode("utf-8")).hexdigest()

def check(deadline):
 if time.monotonic_ns()>=deadline:raise TimeoutError("layout screen deadline")

def review_rank(item_id):return sha(SEED+"\0"+item_id),item_id.encode("utf-8")

def inspect_cases(rows,components,slots,deadline):
 """Four layouts are experimental variants; content checks cannot certify semantics."""
 groups={}
 for row in rows:
  check(deadline);iid=row["item_id"];lid=row["layout_id"]
  assert type(iid)is str and lid in LAYOUTS
  assert not {"output","gold","reference","expected"}&row.keys()
  g=groups.setdefault(iid,{})
  assert lid not in g;g[lid]=row
 assert set(groups)=={"sample_"+str(i)for i in range(800)}
                                                                            
 selected=sorted(groups,key=review_rank)[:50]
 assert len(components["examples"])==2
 instruction=components["instruction"];examples=components["examples"]
 assert type(instruction)is str and all(type(v)is str for v in examples)
 checks=[];review=[];comparisons=[]
 for iid in sorted(groups,key=lambda s:int(s.split("_")[1])):
  check(deadline);g=groups[iid];assert set(g)==set(LAYOUTS);baseline=g["layout-0"]
  assert all(type(baseline[k])is str for k in ("code","input","payload"))
                                                                                   
  payload="[PYTHON]\n"+baseline["code"]+"\nassert f("+baseline["input"]+") == ??\n[/PYTHON]\n[ANSWER]\n"
  try:
   ast.parse(baseline["code"]);ast.parse("f("+baseline["input"]+")",mode="eval")
   syntax="PARSES_WITHOUT_EXECUTION"
  except (SyntaxError,ValueError,TypeError):syntax="SYNTAX_UNKNOWN"
  if baseline["input"]=="":
   input_shape="EMPTY_ARGUMENT_TEXT"
  else:
   try:ast.literal_eval(baseline["input"]);input_shape="LITERAL_EVAL_ACCEPTS"
   except (ValueError,SyntaxError,TypeError,MemoryError,RecursionError):input_shape="NON_LITERAL_OR_UNRESOLVED"
  for j,lid in enumerate(LAYOUTS):
   row=g[lid];first=j<2;reverse=j%2==1
   ex=list(reversed(examples))if reverse else list(examples)
   parts=[instruction,"\n".join(ex),payload]if first else["\n".join(ex),instruction,payload]
   expected="\n\n".join(parts)
   fields=("code","input","payload","prompt")
   for k in fields:assert type(row[k])is str
   hashes_match=all(row[k+"_sha256"]==sha(row[k])for k in fields)
   content=dict(code_equal=row["code"]==baseline["code"],
    input_equal=row["input"]==baseline["input"],payload_equal=row["payload"]==payload,
    instruction_hash_equal=row["instruction_sha256"]==sha(instruction),
    declared_instruction_first_equal=row["instruction_first"]is first,
    declared_example_order_equal=row["example_order"]==("reversed"if reverse else"original"),
    prompt_reconstruction_equal=row["prompt"]==expected,hashes_match=hashes_match)
   checks.append(dict(item_id=iid,layout_id=lid,prompt_sha256=row["prompt_sha256"],
    prompt_UTF8_bytes=len(row["prompt"].encode()),checks=content,
    syntax_status=syntax,input_syntax_shape=input_shape,semantic_equivalence="UNREVIEWED"))
   if lid!="layout-0":
    comparisons.append(dict(item_id=iid,baseline="layout-0",variant=lid,
     baseline_prompt_sha256=baseline["prompt_sha256"],variant_prompt_sha256=row["prompt_sha256"],
     same_code=row["code"]==baseline["code"],same_input=row["input"]==baseline["input"],
     same_payload=row["payload"]==baseline["payload"],human_status="UNREVIEWED"))
  if iid in selected:
                                                                                      
   review.append(dict(group_id="TD7_LAYOUT50_V1__"+iid,item_id=iid,
    rank_sha256=review_rank(iid)[0],human_status="UNREVIEWED",human_label=None,
    human_identity=None,annotation_source="NONE",
    layouts=[dict(layout_id=lid,prompt=g[lid]["prompt"],prompt_sha256=g[lid]["prompt_sha256"])for lid in LAYOUTS],
    comparisons=[dict(baseline="layout-0",variant=lid,human_status="UNREVIEWED",human_label=None)for lid in LAYOUTS[1:]]))
 bykey={}
 modelkeys=set()
 for slot in slots:
  check(deadline);key=(slot["model_key"],slot["item_id"],slot["layout_id"])
  assert key not in bykey;bykey[key]=slot;modelkeys.add(key[0])
  assert slot["item_id"]in groups and slot["layout_id"]in LAYOUTS
  assert slot["prompt_sha256"]==groups[key[1]][key[2]]["prompt_sha256"]
 assert len(modelkeys)==2 and len(slots)==6400
 assert set(bykey)=={(m,i,l)for m in modelkeys for i in groups for l in LAYOUTS}
 assert len(checks)==3200 and len(comparisons)==2400 and len(review)==50
 return dict(checks=checks,all_comparisons=comparisons,review_groups=review,
  selected_item_ids=selected,model_keys=sorted(modelkeys),selection_seed=SEED,
  selection_first_frozen_now=True,old_selected_ID_manifest_existed=False,
  planned_groups=50,review_prompts=200,review_nonbaseline_comparisons=150,
  full_fixed_items=800,full_fixed_prompts=3200,fixed_model_slots=6400,
  human_Gold=0,human_status="UNREVIEWED",
  semantic_equivalence_certified=False,diagnostic_shapes_not_selection_criteria=True)
