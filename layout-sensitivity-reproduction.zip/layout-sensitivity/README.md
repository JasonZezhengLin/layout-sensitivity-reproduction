# Layout sensitivity: structural replication

This archive accompanies *Auditing Layout Sensitivity in Code-Reasoning Evaluation*.
It reproduces the reported structural/content screen and the fixed selection for
semantic review: 800 groups, 3,200 layouts, 2,400 nonbaseline comparisons,
6,400 planned model slots, and 50 selected groups (200 prompts, 150 comparisons).
Human labels are blank and human_Gold is zero. Model slots describe planned
inputs; they contain no completed model outputs or model-score evidence.

## Run

Use Python 3.14 (validated with 3.14.0), without installing dependencies.
From the extracted directory run:

    python3 -B reproduce.py

The program reads the supplied data, recomputes every structural check and the
selection, and compares complete structures against the saved results. It also
checks that all 150 annotation rows remain blank. It exits nonzero on a mismatch
and writes regenerated files into a fresh `generated/` directory. To repeat, use
another extracted directory or pass `--output another-directory`.

The experimental prompts in `data/` are study stimuli, including the benchmark
instruction, two examples, and layout variants. They are needed to reconstruct
the evaluated inputs. No target code is executed and no model, tokenizer,
network connection, credentials, GPU, or annotation service is used by this run.
The checks establish literal content and layout reconstruction, with semantic
equivalence still UNREVIEWED.

## Data and interpretation

`data/cases.jsonl` contains the four layouts for each item;
`data/components.json` contains their shared instruction/examples;
`data/model_slots.jsonl` fixes the two-model Cartesian product;
`data/semantic_review_groups.json` and `data/annotation_template.tsv` provide
the frozen review inputs and blank labels. `results/` holds the observed
structural results and summary reproduced by the command above. Per-stimulus
digests are experimental identifiers used by the structural checks.

The selection orders item identifiers by SHA-256 of UTF-8 seed,
a NUL byte, and UTF-8 item identifier, then takes the first 50. The seed is
`TD7_LAYOUT_SEMANTIC50_V1`. Syntax diagnostics do not affect selection.
Semantic review and learned evaluation require their own outcomes before
interpreting model sensitivity; this archive reports the completed static work.

## Sources and license

Benchmark code/input items and prompt components derive from CRUXEval:
https://github.com/facebookresearch/cruxeval
and https://arxiv.org/abs/2401.03065v1
(DOI: 10.48550/arXiv.2401.03065).
Its MIT license and required copyright notice are retained verbatim in
`LICENSES/CRUXEval-LICENSE.txt`.
