from pathlib import Path
import argparse,csv,json,time
from layout_screen import inspect_cases

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',default='generated');a=p.parse_args()
 root=Path(__file__).resolve().parent
 def load(name):return json.loads((root/name).read_text(encoding='utf-8'))
 def rows(name):return [json.loads(s)for s in (root/name).read_text(encoding='utf-8').splitlines()]
 r=inspect_cases(rows('data/cases.jsonl'),load('data/components.json'),rows('data/model_slots.jsonl'),time.monotonic_ns()+60_000_000_000)
 structural={'checks':r['checks'],'comparisons':r['all_comparisons'],'scope':'Machine source-content and fixed-layout checks; human semantics remain UNREVIEWED'}
 assert structural==load('results/structural.json'),'Structural result mismatch'
 expected=load('results/summary.json');summary={k:r[k]for k in expected}
 assert summary==expected,'Summary mismatch'
 assert r['review_groups']==load('data/semantic_review_groups.json')['groups'],'Review input mismatch'
 with (root/'data/annotation_template.tsv').open(newline='',encoding='utf-8')as f:annotations=list(csv.DictReader(f,delimiter='\t'))
 assert len(annotations)==150
 assert all(not row[k]for row in annotations for k in ('label','reason','reviewer','reviewed_at'))
 expected_comparisons={(g['group_id'],g['item_id'],'layout-0',v['layout_id'],g['layouts'][0]['prompt_sha256'],v['prompt_sha256'])for g in r['review_groups']for v in g['layouts'][1:]}
 actual={(x['group_id'],x['item_id'],x['baseline_layout'],x['variant_layout'],x['baseline_prompt_sha256'],x['variant_prompt_sha256'])for x in annotations}
 assert actual==expected_comparisons,'Annotation identities mismatch'
 out=Path(a.output);out.mkdir(exist_ok=False)
 for name,obj in [('structural.json',structural),('summary.json',summary),('semantic_review_groups.json',r['review_groups'])]:
  (out/name).write_text(json.dumps(obj,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')
 print('PASS: 800 groups; 3200 layouts; 2400 comparisons; 6400 planned slots; 50 review groups; 150 blank annotations; human labels 0.')
if __name__=='__main__':main()
